package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation v2 — 2-tick pattern (Grim-safe).
 *
 * Pattern đúng:
 *   tick N   → setPendingRotation(rot)
 *   beforeSync (tick N) → applySilent(rot) → movement packet mang rot này
 *   tick N+1 → interact (Grim thấy hit vector khớp movement packet trước)
 *              → clearPending() + restore
 *
 * Grim kiểm tra: last movement packet yaw/pitch phải khớp với
 * hit vector của interactBlock. Nếu apply và restore trong cùng tick,
 * movement packet chưa gửi → flag "impossible rotation".
 */
public final class RotationUtil {
    private RotationUtil() {}

    // Pending rotation — set trước sendMovementPackets, clear sau interact
    private static volatile float[] pendingRot  = null;
    private static volatile float   savedYaw    = 0f;
    private static volatile float   savedPitch  = 0f;
    private static volatile boolean hasPending  = false;

    /**
     * Lưu rotation cần dùng. Gọi TRƯỚC beforeSync.
     * beforeSync sẽ apply lên player + movement packet sẽ mang rot này.
     */
    public static void setPending(ClientPlayerEntity player, float[] rot) {
        savedYaw   = player.getYaw();
        savedPitch = player.getPitch();
        pendingRot = rot;
        hasPending = true;
    }

    /**
     * Gọi từ beforeSync (hook vào sendMovementPackets).
     * Apply rotation TRƯỚC khi movement packet gửi đi.
     * Trả true nếu có pending.
     */
    public static boolean applyBeforeSync(ClientPlayerEntity player) {
        if (!hasPending || pendingRot == null) return false;
        applyRaw(player, pendingRot);
        return true;
    }

    /**
     * Gọi SAU khi interactBlock xong.
     * Restore về rotation gốc.
     */
    public static void restoreAfterInteract(ClientPlayerEntity player) {
        if (!hasPending) return;
        hasPending = false;
        pendingRot = null;
        applyRaw(player, new float[]{ savedYaw, savedPitch });
    }

    public static boolean hasPendingRotation() {
        return hasPending;
    }

    /**
     * Tính yaw/pitch để nhìn vào hitVec.
     */
    public static float[] calcRotation(ClientPlayerEntity player, Vec3d target) {
        Vec3d eyes = player.getEyePos();
        double dx = target.x - eyes.x;
        double dy = target.y - eyes.y;
        double dz = target.z - eyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw   = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    /**
     * Hit vector plausible: center của face được nhìn vào,
     * + small random offset để trông natural.
     */
    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    private static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];
        player.bodyYaw = rot[0];
        // lastBodyYaw/lastHeadYaw — set để interpolation delta = 0 trong tick này
        player.lastBodyYaw = rot[0];
        player.lastHeadYaw = rot[0];
    }
}
